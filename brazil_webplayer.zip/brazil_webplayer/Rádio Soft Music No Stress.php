<?php


   $img_link = "http://structuredapps.live/playstore/9186eb0e475eeff5c6856e8ed43eb31e_w200.gif";
   $audio_link = "http://cast.midiaip.com.br:6012/stream/;";
   $html = "
       <body>
       
             <h1 style='text-align: center;'><img src='$img_link' alt='Girl in a jacket' width='100' height='100'/></h1>
             
             <h1 style='text-align: center;'>Rádio Soft Music No Stress</h1>
             <h1 style='text-align: center;'>
                <audio controls>
                  <source src='$audio_link' type='audio/ogg'>
                  <source src='$audio_link' type='audio/mpeg'>
                  Your browser does not support the audio element.
                </audio>
             </h1>
             
       </body>
   ";
   
   echo $html
?>