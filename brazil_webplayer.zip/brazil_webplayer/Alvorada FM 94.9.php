<?php


   $img_link = "https://structuredappsstreaming.win/9186eb0e475eeff5c6856e8ed43eb31e_w200.gif";
   $audio_link = "https://24493.live.streamtheworld.com/RADIO_ALVORADA.mp3?DIST=TuneIn&TGT=TuneIn&maxServers=2&gdpr=0&us_privacy=1YNY&partnertok=eyJhbGciOiJIUzI1NiIsImtpZCI6InR1bmVpbiIsInR5cCI6IkpXVCJ9.eyJ0cnVzdGVkX3BhcnRuZXIiOnRydWUsImlhdCI6MTY5MjE0MTEyMCwiaXNzIjoidGlzcnYifQ.pU8qVlkjqeLlN3hI9ZyrxolQ4eoD15X8TYnqU95ThsU";
   $html = "
       <body>
       
             <h1 style='text-align: center;'><img src='$img_link' alt='Girl in a jacket' width='100' height='100'/></h1>
             
             <h1 style='text-align: center;'>Alvorada FM 94.9</h1>
             <h1 style='text-align: center;'>
                <audio controls>
                  <source src='$audio_link' type='audio/ogg'>
                  <source src='$audio_link' type='audio/mpeg'>
                  Your browser does not support the audio element.
                </audio>
             </h1>
             
       </body>
   ";
   
   echo $html
?>